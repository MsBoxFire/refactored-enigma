
# Types

The primitive types: `num` and `bool`.

The true and false value for boolean type is `true` and `false`.

# Syntaxes

Syntax forms:

```
E = b           # Integer or boolean

  | X           # Variable
  
  | (E)         # Parenthesized expression
  
  | (E1 E2)       # Function application
  
  | (o E ...)   # Primitive operation
  
  | \X.E        # Lambda
  
  | (if E1 E2 E3)  # If E1 evaluates to True, E2 is evaluated and returned,
                   # otherwise E3 is evaluated and returned.
                   # Unlike other syntax forms, which are call-by-value,
                   # E2 and E3 are only evaluated when necessary.
                   
  | { name1 = E1, name2 = E2, ... }
                   # Construct a record with the fields name1, name2, etc. and
                   # the corresponding values.
                   # The order of fields doesn't matter.
                   
  | E.field        # Select a field of a record.
```

There is a shortcut for multiple parameter functions, e.g.,

```
\a b c. E   ==   \a.\b.\c.E
```

and a shortcut for multiple argument function calls, e.g.,

```
(f a b c)   ==   (((f a) b) c)
```

Primitive operations:

```
prim = (+ E E)
     | (- E E)
     | (* E E)
     | (/ E E)
     | (% E E)   # Calculate remainder
     | (^ E E)   # Calculate exponentation
     | (add1 E)
     | (sub1 E)
     | (iszero E)
     | (= E E)
     | (> E E)
     | (< E E)
     | (not E)
```

The syntax of typed lambdas is as following:

```
\param : type . body

```

The syntax of types is as following:

```
type = num
     | bool
     | (type -> type)
     | {name1 : type2, name2 : type2, ..., name_n : type_n}   # record type
```

For example, `\f: (num -> bool). (f 3)` is a lambda that given a function maps
a number to a boolean, apply it to 3.

The order of fields of a record type doesn't matter when applying row
polymorphism.

# Modules

- `iswim` is the main functions.  
- `parse` is parser.  
    `parse_untyped()` receives a string of an ISWIM expression without any type annotations.
    `parse_typed()` receives a string of an ISWIM expression with lambda parameter
    is annotated with a type. And record type is supported.
- `secd` is SECD machine.  
    Use: `run_secd(ast_node)`
    this machine doesn't support records.
- `cek` is CEK machine.  
    Use: `run_cek(ast_node)`
- `typeinference` is type inferrer and type checker.  
- `typecheck` is type checker.  
    Record and row polymorphism is supported.
- `ast` is Abstract Syntax Tree for ISWIM.  
- `type` is class definitions of types of ISWIM.  

# Testing

Test parser:

```shell
python3 -m tests.parse_test
```

Test SECD machine:

```shell
python3 -m tests.secd_test
```