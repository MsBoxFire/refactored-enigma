import unittest
from src.typeinference import type_check
from src.parse import parse_untyped
from src.type import *


class TestTypeChecker(unittest.TestCase):

    def assertTypeEqual(self, actual, expected):

        if not type_equal(actual, expected):

            self.fail(
                'Type mismatch: %s != %s' %
                (actual, expected))

    def test_lambda(self):

        self.assertTypeEqual(type_check(parse_untyped(
            r'\w.w')),
            FuncType(VarType('a'), VarType('a')))

        self.assertTypeEqual(type_check(parse_untyped(
            r'\w.((\y.y) w)')),
            FuncType(VarType('a'), VarType('a')))

    def test_example_1(self):

        self.assertTypeEqual(type_check(parse_untyped(
            r'((\x.x) 0)')),
            NumType())

    def test_example_2(self):

        self.assertTypeEqual(type_check(parse_untyped(
            r'((\f.(f 0)) (\x.x))')),
            NumType())

    def test_ex_16_1(self):

        self.assertTypeEqual(type_check(parse_untyped(
            r'(\x.(+ 0 ((\y.y) x)))')),
            FuncType(NumType(), NumType()))

    def test_omega(self):

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(\w.(w w))'))

    def test_ap(self):

        self.assertTypeEqual(type_check(parse_untyped(
            r'((\x.x) 1)')),
            NumType())

        self.assertTypeEqual(type_check(parse_untyped(
            r'((\f.(f (f 30))) (\x.(+ x 2)))')),
            NumType())

        self.assertTypeEqual(type_check(parse_untyped(
            r'((\f.(f (f 2 3))) (\x y.y))')),
            FuncType(NumType(), NumType()))

    def test_prim(self):

        self.assertTypeEqual(type_check(parse_untyped(
            r'\x.(+ x 1)')),
            FuncType(NumType(), NumType()))

        self.assertTypeEqual(type_check(parse_untyped(
            r'(* (sub1 30) 1)')),
            NumType())

        self.assertTypeEqual(type_check(parse_untyped(
            r'(not (iszero 7))')),
            BoolType())

        self.assertTypeEqual(type_check(parse_untyped(
            r'(not (> 3 ((\x.(add1 x)) 3)))')),
            BoolType())

    def test_ap_mismatch(self):

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(3 1)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'((\f.(f (iszero (f 3)))) (\x.x))'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'((\f.(f true)) (\x.(add1 x)))'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(((\x.x) (\x.x)) 3 4)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'((\f.(f (f 30))) (\x.(iszero x)))'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'((\f.(not (f (iszero (f 30))))) (\x.x))'))

    def test_prim_mismatch(self):

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(+ 3 true)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(+ 3)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(* (iszero 20) 30)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(= (> 20 20) 30)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(not (/ 20 20))'))

    def test_var_not_found(self):

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'x'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'((\x.y) 30)'))

    def test_if(self):

        self.assertTypeEqual(type_check(parse_untyped(
            r'(if true 1 2)')),
            NumType())

        self.assertTypeEqual(type_check(parse_untyped(
            r'(if (iszero 3) (\x.x) (\y.y))')),
            FuncType(VarType('a'), VarType('a')))

        self.assertTypeEqual(type_check(parse_untyped(
            r'(if (iszero 3) (\x.x) (\y.(add1 y)))')),
            FuncType(NumType(), NumType()))

        self.assertTypeEqual(type_check(parse_untyped(
            r'((if (> ((\x.(* 3 x)) 30) 3) (\x.x) (\y.y)) 17)')),
            NumType())

        self.assertTypeEqual(type_check(parse_untyped(
            r'((if (iszero 3) (\x.x) (\y.y)) 17)')),
            NumType())

        self.assertTypeEqual(type_check(parse_untyped(
            r'((if (iszero 3) (\x.x) (\y.(sub1 y))) 17)')),
            NumType())

    def test_if_mismatch(self):

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(if 30 1 2)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(if (+ 20 2) 1 3)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(if true 1 false)'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(if true (\x.x) (\x y.x))'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(if true (\x.(iszero x)) (\x.(add1 x)))'))

        with self.assertRaises(TypingError):
            type_check(parse_untyped(
                r'(if true (\x.(not x)) (\x.(> x 2)))'))


if __name__ == '__main__':
    unittest.main()
