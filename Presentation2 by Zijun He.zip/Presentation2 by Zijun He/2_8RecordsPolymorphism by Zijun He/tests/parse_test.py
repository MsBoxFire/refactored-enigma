import unittest
from src.parse import parse_untyped, parse_typed
from src.ast import *


class TestParseUntyped(unittest.TestCase):

    def test_primitives(self):

        self.assertEqual(parse_untyped(r'7'), ConstNode(7))

        self.assertEqual(parse_untyped(r'123'), ConstNode(123))

        self.assertEqual(parse_untyped(r'x'), VarNode('x'))

        self.assertEqual(parse_untyped(r'xyz'), VarNode('xyz'))

        self.assertEqual(parse_untyped(r'x3Z'), VarNode('x3Z'))

        self.assertEqual(parse_untyped(r'true'), TrueNode())

        self.assertEqual(parse_untyped(r'false'), FalseNode())

    def test_spaces(self):

        self.assertEqual(
            parse_untyped(r'  12'),
            ConstNode(12))

        self.assertEqual(
            parse_untyped(r'(+ x y)  '),
            PrimApNode(Primitives.Add, [VarNode('x'), VarNode('y')]))

        self.assertEqual(
            parse_untyped(r'   \x.x'),
            LambdaNode('x', VarNode('x')))

        self.assertEqual(
            parse_untyped(r'   \ x .  x  '),
            LambdaNode('x', VarNode('x')))

    def test_lambda(self):

        self.assertEqual(
            parse_untyped(r'\xy.xxx'),
            LambdaNode('xy', VarNode('xxx')))

        self.assertEqual(
            parse_untyped(r'\x.\y.k'),
            LambdaNode('x', LambdaNode('y', VarNode('k'))))

        self.assertEqual(
            parse_untyped(r'\x y z. k1'),
            LambdaNode('x', LambdaNode('y', LambdaNode('z', VarNode('k1')))))

    def test_ap(self):

        self.assertEqual(
            parse_untyped(r'(\x.x 34)'),
            ApNode(LambdaNode('x', VarNode('x')), ConstNode(34)))

        self.assertEqual(
            parse_untyped(r'((\x.x xx) yy)'),
            ApNode(ApNode(LambdaNode('x', VarNode('x')),
                          VarNode('xx')),
                   VarNode('yy')))

        self.assertEqual(
            parse_untyped(r'(\x.x xx yy)'),
            ApNode(ApNode(LambdaNode('x', VarNode('x')),
                          VarNode('xx')),
                   VarNode('yy')))

    def test_prim_ap(self):

        self.assertEqual(
            parse_untyped(r'(+ 20 x)'),
            PrimApNode(Primitives.Add, [ConstNode(20), VarNode('x')]))

        self.assertEqual(
            parse_untyped(r'\x.(add1 x)'),
            LambdaNode('x', PrimApNode(Primitives.Add1,
                                       [VarNode('x')])))

        self.assertEqual(
            parse_untyped(r'(iszero xyz)'),
            PrimApNode(Primitives.IsZero,
                       [VarNode('xyz')]))

        self.assertEqual(
            parse_untyped(r'(< xyz false)'),
            PrimApNode(Primitives.Lt,
                       [VarNode('xyz'), FalseNode()]))

        self.assertEqual(
            parse_untyped(r'(not (= 37 true))'),
            PrimApNode(Primitives.Not,
                       [PrimApNode(Primitives.Eq,
                                   [ConstNode(37), TrueNode()])]))

    def test_if(self):

        self.assertEqual(
            parse_untyped(r'(if 20 xy true)'),
            IfNode(ConstNode(20), VarNode('xy'), TrueNode()))

        self.assertEqual(
            parse_untyped(r'(if (> (+ x 2) y) xy true)'),
            IfNode(
                PrimApNode(
                    Primitives.Gt,
                    [PrimApNode(Primitives.Add, [VarNode('x'), ConstNode(2)]),
                     VarNode('y')]),
                VarNode('xy'),
                TrueNode()))

    def test_paren(self):

        self.assertEqual(
            parse_untyped(r'(\x.x)'),
            LambdaNode('x', VarNode('x')))

        self.assertEqual(
            parse_untyped(r'(((\x.x)))'),
            LambdaNode('x', VarNode('x')))

        self.assertEqual(
            parse_untyped(r'((\x.x) yy)'),
            ApNode(LambdaNode('x', VarNode('x')), VarNode('yy')))


class TestParseTyped(unittest.TestCase):

    def test_lambda(self):

        self.assertEqual(
            parse_typed(r'\x : num. (+ x 1)'),
            LambdaNode('x',
                       PrimApNode(Primitives.Add,
                                  [VarNode('x'), ConstNode(1)]),
                       NumType()))

        self.assertEqual(
            parse_typed(r'\x : (num -> bool). (+ x 1)'),
            LambdaNode('x',
                       PrimApNode(Primitives.Add,
                                  [VarNode('x'), ConstNode(1)]),
                       FuncType(NumType(), BoolType())))

        self.assertEqual(
            parse_typed(r'((\x : (num -> (bool -> num)). x) 30)'),
            ApNode(
                LambdaNode('x',
                           VarNode('x'),
                           FuncType(NumType(),
                                    FuncType(BoolType(), NumType()))),
                ConstNode(30)))

        self.assertEqual(
            parse_typed(r'((\x : (num -> (bool -> num)). x) 30)'),
            ApNode(
                LambdaNode('x',
                           VarNode('x'),
                           FuncType(NumType(),
                                    FuncType(BoolType(), NumType()))),
                ConstNode(30)))

        self.assertEqual(
            parse_typed(r'\x: bool y: (num -> num). (y x)'),
            LambdaNode('x',
                       LambdaNode('y',
                                  ApNode(VarNode('y'),
                                         VarNode('x')),
                                  FuncType(NumType(), NumType())),
                       BoolType()))

    def test_record(self):

        self.assertEqual(
            parse_typed(r'{as=3}'),
            RecordNode([('as', ConstNode(3))]))

        self.assertEqual(
            parse_typed(r'{ab=3, cde = (iszero 20) , a=true,zzzz=false}'),
            RecordNode([('ab', ConstNode(3)),
                        ('cde', PrimApNode(Primitives.IsZero,
                                           [ConstNode(20)])),
                        ('a', TrueNode()),
                        ('zzzz', FalseNode())]))

        self.assertEqual(
            parse_typed(r'{as=3, x={x=y,a=12}}'),
            RecordNode([('as', ConstNode(3)),
                        ('x', RecordNode([('x', VarNode('y')),
                                          ('a', ConstNode(12))]))]))

    def test_selection(self):

        self.assertEqual(
            parse_typed(r'ab.name'),
            SelectionNode(VarNode('ab'), 'name'))

        self.assertEqual(
            parse_typed(r'(+ 2 3).color'),
            SelectionNode(PrimApNode(Primitives.Add,
                                     [ConstNode(2), ConstNode(3)]),
                          'color'))

        self.assertEqual(
            parse_typed(r'{as = 30}.name'),
            SelectionNode(RecordNode([('as', ConstNode(30))]),
                          'name'))

        self.assertEqual(
            parse_typed(r'(f 2 ab . name)'),
            ApNode(ApNode(VarNode('f'), ConstNode(2)),
                   SelectionNode(VarNode('ab'), 'name')))

    def test_record_type(self):

        self.assertEqual(
            parse_typed(r'\x : {size: num}. (+ x 1)'),
            LambdaNode('x',
                       PrimApNode(Primitives.Add,
                                  [VarNode('x'), ConstNode(1)]),
                       RecordType([('size', NumType())])))

        self.assertEqual(
            parse_typed(r'\x : {size: num, color: bool}. (x.age)'),
            LambdaNode('x',
                       SelectionNode(VarNode('x'), 'age'),
                       RecordType([('size', NumType()),
                                   ('color', BoolType())])))

        self.assertEqual(
            parse_typed(r'\x : {succ: (num -> num), zero: num}. (x.succ x.zero)'
                        ),
            LambdaNode('x',
                       ApNode(SelectionNode(VarNode('x'), 'succ'),
                              SelectionNode(VarNode('x'), 'zero')),
                       RecordType([('succ', FuncType(NumType(), NumType())),
                                   ('zero', NumType())])))


if __name__ == '__main__':
    unittest.main()
