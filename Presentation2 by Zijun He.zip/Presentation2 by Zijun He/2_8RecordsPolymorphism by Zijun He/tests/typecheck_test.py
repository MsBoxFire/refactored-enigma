import unittest
from src.typecheck import type_check
from src.parse import parse_typed
from src.type import *


class TestTypeChecker(unittest.TestCase):

    def test_lambda(self):

        self.assertEqual(
            type_check(parse_typed(r'\x: num. (add1 x)')),
            FuncType(NumType(), NumType()))

        self.assertEqual(
            type_check(parse_typed(r'\x: (num -> bool). (x 30)')),
            FuncType(FuncType(NumType(), BoolType()), BoolType()))

        self.assertEqual(
            type_check(parse_typed(r'\x: (num -> bool). (x 30)')),
            FuncType(FuncType(NumType(), BoolType()), BoolType()))

    def test_lambda_invalid(self):

        with self.assertRaises(TypingError):
            type_check(parse_typed(r'\x: bool. (add1 true)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(r'\x: bool. (add1 x)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(r'\x: bool. (+ 3)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(r'\x: num. (x 3)'))

    def test_ap(self):

        self.assertEqual(
            type_check(parse_typed(r'((\x: num. (add1 x)) 10)')),
            NumType())

        self.assertEqual(
            type_check(parse_typed(r'((\x: num. (not (iszero x))) 10)')),
            BoolType())

        self.assertEqual(
            type_check(parse_typed(r'((\f: (num -> num). (iszero (f 10)))'
                                   r' (\x: num. (add1 x)))')),
            BoolType())

    def test_ap_invalid(self):

        with self.assertRaises(TypingError):
            type_check(parse_typed(r'(f 3)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(r'((\x: num. x) true)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: (num -> num). (x 30)) (\x: num. (iszero x)))'))

    def test_13_1(self):

        self.assertEqual(
            type_check(parse_typed(
                r'((\x: num. \y: (num -> bool). (y x))'
                r' 10 (\z: num. (iszero z)))')),
            BoolType())

    def test_if(self):

        self.assertEqual(
            type_check(parse_typed(
                r'(if (> 3 2) 20 (+ 1 30))')),
            NumType())

        self.assertEqual(
            type_check(parse_typed(
                r'(if (not false) (\x: num. x) (\x: num. (add1 x)))')),
            FuncType(NumType(), NumType()))

        self.assertEqual(
            type_check(parse_typed(
                r'(if ((\x: num. (iszero x)) 30) (not (iszero 0)) true)')),
            BoolType())

    def test_if_invalid(self):

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if (+ 20 1) 1 2)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'\x: num. (if (+ x 3) 1 2)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if true false 2)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if (not false) (\x: num. x) 2)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if false (\x: num. x) (\x: num. (iszero x)))'))

    def test_record(self):

        self.assertEqual(
            type_check(parse_typed(
                r'{ a = 3 }')),
            RecordType([('a', NumType())]))

        self.assertEqual(
            type_check(parse_typed(
                r'{ age = 2, class = false }')),
            RecordType([('age', NumType()),
                        ('class', BoolType())]))

        self.assertEqual(
            type_check(parse_typed(
                r'{ succ = (\x: num. (add1 x)), zero = 0 }')),
            RecordType([('succ', FuncType(NumType(), NumType())),
                        ('zero', NumType())]))

        self.assertEqual(
            type_check(parse_typed(
                r'{ base = { x = (iszero 3), y = (\x: num. true) },'
                r'           z = 30 }')),
            RecordType([('base', RecordType([('x', BoolType()),
                                             ('y', FuncType(NumType(),
                                                            BoolType()))])),
                        ('z', NumType())]))

    def test_selection(self):

        self.assertEqual(
            type_check(parse_typed(
                r'{ a = 3 }.a')),
            NumType())

        self.assertEqual(
            type_check(parse_typed(
                r'({ size = false, age = 40 }).size')),
            BoolType())

        self.assertEqual(
            type_check(parse_typed(
                r'({ succ = (\x: num. (add1 x)), zero = 0 }).succ')),
            FuncType(NumType(), NumType()))

        self.assertEqual(
            type_check(parse_typed(
                r'((\x: {succ: (num -> num), zero: num}.'
                r'   (x.succ (x.succ x.zero)))'
                r' { succ = (\x: num. (add1 x)), zero = 0 })')),
            NumType())

        self.assertEqual(
            type_check(parse_typed(
                r'({ more = { get = (\f: (num -> bool). (f 7)),'
                r'            put = (not true) },'
                r'   less = 0,'
                r'   yes = false })'
                r' .more.get')),
            FuncType(FuncType(NumType(), BoolType()), BoolType()))

    def test_selection_invalid(self):

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'30.a'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'true.size'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'{ a = 3 }.b'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(+ {a = true}.a 40)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'{a = true}.a.b'))

    def test_row_polymorphism(self):

        self.assertEqual(
            type_check(parse_typed(
                r'((\x: {size: num}. (add1 x.size)) { size = 40 })')),
            NumType())

        self.assertEqual(
            type_check(parse_typed(
                r'((\x: {size: num}. (iszero x.size))'
                r' { size = 40, age = true })')),
            BoolType())

        self.assertEqual(
            type_check(parse_typed(
                r'((\x: {age: bool}. (not x.age))'
                r' { size = 40, age = true })')),
            BoolType())

        self.assertEqual(
            type_check(parse_typed(
                r'((\p: {x: num, y: num}. (+ p.x p.y))'
                r' { y = 4, z = 8, x = 3 })')),
            NumType())

        self.assertEqual(
            type_check(parse_typed(
                r'((\p: {succ: (num -> num) }. p.succ)'
                r' { succ = (\x: num. (add1 x)), zero = 0 })')),
            FuncType(NumType(), NumType()))

        self.assertEqual(
            type_check(parse_typed(
                r'((\p: {succ: (num -> num) }. (p.succ 30))'
                r' { succ = (\x: num. (add1 x)), zero = 0 })')),
            NumType())

        self.assertEqual(
            type_check(parse_typed(
                r'((\x: {more: { yes: bool, no: bool } }. (not x.more.no))'
                r' { size = 40, more = { yes = true, no = false } })')),
            BoolType())

    def test_row_polymorphism_invalid(self):

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: num. x) { a = 3 })'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: { a: num }. x.a) true)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: { b: num }. x.b) { a = 3 })'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: { a: num, b: num }. x.b) { a = 3 })'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: { a: num, b: num }. x.b) { a = 3, c = 200 })'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: { a: num, b: num }. x.b) { a = 3, b = false })'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: { a: { x: num, y: bool }, b: bool }. x.b)'
                r' { a = { x = 3, y = 4 }, b = false })'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: { a: { x: num }, b: bool }. x.b)'
                r' { a = { x = 3, y = 4 }, b = false })'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'((\x: { a: { x: num, y: num }, b: bool }. x.b)'
                r' { a = { x = 3 }, b = false })'))

    def test_if_record(self):

        self.assertEqual(
            type_check(parse_typed(
                r'(if true {x=3} {x=7})')),
            RecordType([('x', NumType())]))

        self.assertEqual(
            type_check(parse_typed(
                r'(if true {x=3,y=4} {x=7})')),
            RecordType([('x', NumType())]))

        self.assertEqual(
            type_check(parse_typed(
                r'(if true {x=3} {y=12,x=7})')),
            RecordType([('x', NumType())]))

    def test_if_record_invalid(self):

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if true 7 {x=3})'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if true {x=3} 7)'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if true {x=3} {y=7})'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if true {x=3} {x=true})'))

        with self.assertRaises(TypingError):
            type_check(parse_typed(
                r'(if true {x=3,y=4} {x=3,z=7})'))


if __name__ == '__main__':
    unittest.main()
