
import unittest
from src.stdred import run_stdred
from src.parse import parse_untyped, parse_typed


class TestStdandardReduction(unittest.TestCase):

    def test_primitive(self):

        self.assertEqual(
            run_stdred(parse_untyped(r'30')),
            30)

        self.assertEqual(
            run_stdred(parse_untyped(r'true')),
            True)

        self.assertEqual(
            run_stdred(parse_untyped(r'false')),
            False)

    def test_prim_ap(self):

        self.assertEqual(
            run_stdred(parse_untyped(r'(+ 2 33)')),
            35)

        self.assertEqual(
            run_stdred(parse_untyped(r'(* (+ 12 18) 7)')),
            210)

        self.assertEqual(
            run_stdred(parse_untyped(r'(iszero 0)')),
            True)

        self.assertEqual(
            run_stdred(parse_untyped(r'(iszero 30)')),
            False)

        self.assertEqual(
            run_stdred(parse_untyped(r'(> 30 2)')),
            True)

        self.assertEqual(
            run_stdred(parse_untyped(r'(not true)')),
            False)

    def test_ap(self):

        self.assertEqual(
            run_stdred(parse_untyped(r'((\x y.x) 3 7)')),
            3)

        self.assertEqual(
            run_stdred(parse_untyped(r'((\x y.y) 3 7)')),
            7)

        self.assertEqual(
            run_stdred(parse_untyped(r'((\x.(add1 (* x x))) 7)')),
            50)

    def test_if(self):

        self.assertEqual(
            run_stdred(parse_untyped(r'(if true 12 ((\w.(w w)) (\w.(w w))))')),
            12)

        self.assertEqual(
            run_stdred(parse_untyped(r'(if (> 3 7) 12 37)')),
            37)

        self.assertEqual(
            run_stdred(parse_untyped(
                r'((if (> 7 3) (\x.(add1 x)) (\x.(sub1 x))) 30)')),
            31)

    def test_recursion(self):

        # The call-by-value Y combinator is also called the Z combinator.
        z = r'(\f.((\g. (g g))' \
            r'     (\g x. ((f (g g)) x))))'

        # factorial
        self.assertEqual(
            run_stdred(parse_untyped(
                r'((%s (\f x.'
                r'      (if (= 0 x)'
                r'          1'
                r'          (* x (f (sub1 x))))))'
                r' 5)' % z)),
            120)

        # fibonacci
        self.assertEqual(
            run_stdred(parse_untyped(
                r'((%s (\f x.'
                r'      (if (< x 2)'
                r'          x'
                r'          (+ (f (sub1 x)) (f (- x 2))))))'
                r' 7)' % z)),
            13)

    def test_record(self):

        self.assertEqual(
            run_stdred(parse_typed(r'{a=3,b=true}')),
            {'a': 3, 'b': True})

        self.assertEqual(
            run_stdred(parse_typed(r'{a=(+ 2 3), size={x=4,y=3}}')),
            {'a': 5, 'size': {'x': 4, 'y': 3}})

        self.assertEqual(
            run_stdred(parse_typed(
                r'((\p: {succ: (num -> num), zero: num}.'
                r'   (p.succ (p.succ p.zero)))'
                r' {succ=(\x: num. (+ 2 x)), zero=7})')),
            11)

        self.assertEqual(
            run_stdred(parse_typed(
                r'((\p: {x: num, y: num}.'
                r'   (+ (* p.x p.x) (* p.y p.y)))'
                r' {y = 4, z = 7, x = 3})')),
            25)

        self.assertEqual(
            run_stdred(parse_typed(
                r'(if (> 3 2) {x=3} {x=4})')),
            {'x': 3})

        self.assertEqual(
            run_stdred(parse_typed(
                r'(if (> 3 2) {x=3,y=true} {x=4})')),
            {'x': 3, 'y': True})


if __name__ == '__main__':
    unittest.main()
