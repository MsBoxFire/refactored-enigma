import unittest
from src.parse import parse_untyped
from src.secd import *


class TestSECD(unittest.TestCase):

    def test_primitive(self):

        self.assertEqual(
            run_secd(parse_untyped(r'30')),
            30)

        self.assertEqual(
            run_secd(parse_untyped(r'true')),
            True)

        self.assertEqual(
            run_secd(parse_untyped(r'false')),
            False)

    def test_prim_ap(self):

        self.assertEqual(
            run_secd(parse_untyped(r'(+ 2 33)')),
            35)

        self.assertEqual(
            run_secd(parse_untyped(r'(* (+ 12 18) 7)')),
            210)

        self.assertEqual(
            run_secd(parse_untyped(r'(iszero 0)')),
            True)

        self.assertEqual(
            run_secd(parse_untyped(r'(iszero 30)')),
            False)

        self.assertEqual(
            run_secd(parse_untyped(r'(> 30 2)')),
            True)

        self.assertEqual(
            run_secd(parse_untyped(r'(not true)')),
            False)

    def test_ap(self):

        self.assertEqual(
            run_secd(parse_untyped(r'((\x y.x) 3 7)')),
            3)

        self.assertEqual(
            run_secd(parse_untyped(r'((\x y.y) 3 7)')),
            7)

        self.assertEqual(
            run_secd(parse_untyped(r'((\x.(add1 (* x x))) 7)')),
            50)

    def test_if(self):

        self.assertEqual(
            run_secd(parse_untyped(r'(if true 12 ((\w.(w w)) (\w.(w w))))')),
            12)

        self.assertEqual(
            run_secd(parse_untyped(r'(if (> 3 7) 12 37)')),
            37)

        self.assertEqual(
            run_secd(parse_untyped(
                r'((if (> 7 3) (\x.(add1 x)) (\x.(sub1 x))) 30)')),
            31)

    def test_recursion(self):

        # The call-by-value Y combinator is also called the Z combinator.
        z = r'(\f.((\g. (g g))' \
            r'     (\g x. ((f (g g)) x))))'

        # factorial
        self.assertEqual(
            run_secd(parse_untyped(
                r'((%s (\f x.'
                r'      (if (= 0 x)'
                r'          1'
                r'          (* x (f (sub1 x))))))'
                r' 5)' % z)),
            120)

        # fibonacci
        self.assertEqual(
            run_secd(parse_untyped(
                r'((%s (\f x.'
                r'      (if (< x 2)'
                r'          x'
                r'          (+ (f (sub1 x)) (f (- x 2))))))'
                r' 7)' % z)),
            13)


if __name__ == '__main__':
    unittest.main()
