from ply import lex
from ply import yacc
from .ast import *
from .type import *
from .util import foldr
from functools import reduce


def make_parser(is_typed):

    tokens = (
        'NUMBER',
        'ID',
        'TRUE',
        'FALSE',
        'IF',
        'NUM',
        'BOOL',
        'ARROW'
    )

    literals = r'()\<>.:=,+-*/%^{}'

    t_ignore = ' \t'
    t_ARROW = r'->'

    def t_NUMBER(t):
        r"""[0-9]+"""
        t.value = int(t.value)
        return t

    def t_ID(t):
        r"""[a-zA-Z_][a-zA-Z0-9_]*"""
        if t.value == 'true':
            t.type = 'TRUE'
        elif t.value == 'false':
            t.type = 'FALSE'
        elif t.value == 'if':
            t.type = 'IF'
        elif t.value == 'num':
            t.type = 'NUM'
        elif t.value == 'bool':
            t.type = 'BOOL'
        else:
            t.type = 'ID'
        return t

    def t_newline(t):
        r"""\n+"""
        t.lexer.lineno += len(t.value)

    def t_error(t):
        raise ValueError('Invalid token %s' % t.value[0])

    lexer = lex.lex()

    def make_prim_ap(var, exprs):
        """
        If var is a primitive operator, return a PrimApNode, otherwise None.
        """

        op = Primitives.from_str(var)
        if op is None:
            return None
        else:
            return PrimApNode(op, exprs)

    def p_expr_num(p):
        r"""expr : NUMBER"""
        p[0] = ConstNode(p[1])

    def p_expr_true(p):
        r"""expr : TRUE"""
        p[0] = TrueNode()

    def p_expr_false(p):
        r"""expr : FALSE"""
        p[0] = FalseNode()

    def p_expr_var(p):
        r"""expr : ID"""
        p[0] = VarNode(p[1])

    def p_expr_lambda(p):
        r"""expr : '\\' params1 '.' expr"""
        p[0] = foldr(lambda param, expr: LambdaNode(param[0], expr, param[1]),
                     p[4], p[2])

    def p_lambda_params1(p):
        r"""params1 : param"""
        p[0] = [p[1]]

    def p_lambda_params1_(p):
        r"""params1 : params1 param"""
        p[0] = p[1] + [p[2]]

    def p_lambda_param(p):
        r"""param : ID opt_type"""
        p[0] = (p[1], p[2])

    def p_expr_if(p):
        r"""expr : '(' IF expr expr expr ')'"""
        p[0] = IfNode(p[3], p[4], p[5])

    def p_expr_prim_ap(p):
        r"""expr : '(' operator exprs1 ')'"""
        p[0] = make_prim_ap(p[2], p[3])
        if p[0] is None:
            raise ValueError("Invalid primitive operator '%s'" % p[2])

    def p_operator(p):
        r"""operator : '+'
                     | '-'
                     | '*'
                     | '/'
                     | '%'
                     | '^'
                     | '>'
                     | '<'
                     | '='"""
        p[0] = p[1]

    def p_expr_ap(p):
        r"""expr : '(' exprs1 ')'"""
        if len(p[2]) > 1 and isinstance(p[2][0], VarNode):
            p[0] = make_prim_ap(p[2][0].variable, p[2][1:])
            if p[0] is not None:
                return
        p[0] = reduce(ApNode, p[2])

    def p_expr_record(p):
        r"""expr : '{' record_fields1 '}'"""
        if not is_typed:
            raise ValueError('record is not supported in untyped ISWIM')
        p[0] = RecordNode(p[2])

    def p_record_fields1(p):
        r"""record_fields1 : record_field"""
        p[0] = [p[1]]

    def p_record_fields1_(p):
        r"""record_fields1 : record_fields1 ',' record_field"""
        p[0] = p[1] + [p[3]]

    def p_record_field(p):
        r"""record_field : ID '=' expr"""
        p[0] = (p[1], p[3])

    def p_expr_selection(p):
        r"""expr : expr '.' ID"""
        p[0] = SelectionNode(p[1], p[3])

    def p_exprs1(p):
        r"""exprs1 : expr"""
        p[0] = [p[1]]

    def p_exprs1_(p):
        r"""exprs1 : exprs1 expr"""
        p[0] = p[1] + [p[2]]

    def p_opt_type(p):
        r"""opt_type : ':' type"""
        if not is_typed:
            raise ValueError(
                'type annotation is not supported in untyped ISWIM')
        p[0] = p[2]

    def p_opt_type_none(p):
        r"""opt_type : """
        if is_typed:
            raise ValueError('type annotation cannot be omitted in typed ISWIM')
        p[0] = None

    def p_type_num(p):
        r"""type : NUM"""
        p[0] = NumType()

    def p_type_bool(p):
        r"""type : BOOL"""
        p[0] = BoolType()

    def p_type_func(p):
        r"""type : '(' type ARROW type ')'"""
        p[0] = FuncType(p[2], p[4])

    def p_type_record(p):
        r"""type : '{' record_field_types1 '}'"""
        p[0] = RecordType(p[2])

    def p_record_field_types1(p):
        r"""record_field_types1 : record_field_type"""
        p[0] = [p[1]]

    def p_record_field_types1_(p):
        r"""record_field_types1 : record_field_types1 ',' record_field_type"""
        p[0] = p[1] + [p[3]]

    def p_record_field_type(p):
        r"""record_field_type : ID ':' type"""
        p[0] = (p[1], p[3])

    def p_error(p):
        if p:
            raise ValueError("Syntax error at '%s'" % p.value)
        else:
            raise ValueError("Syntax error at EOF")

    parser = yacc.yacc(debug=False, write_tables=False)

    def parse(s):
        return parser.parse(s)

    return parse


parse_untyped = make_parser(False)
parse_typed = make_parser(True)
