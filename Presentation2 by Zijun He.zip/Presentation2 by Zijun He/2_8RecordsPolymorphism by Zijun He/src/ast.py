from enum import Enum
from .type import *


class ASTNode:

    def __eq__(self, other):
        return type(self) == type(other) and self.__dict__ == other.__dict__


class ConstNode(ASTNode):

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return str(self.value)

    def __repr__(self):
        return 'Const(%r)' % self.value


class VarNode(ASTNode):

    def __init__(self, variable):
        self.variable = variable

    def __str__(self):
        return self.variable

    def __repr__(self):
        return 'Var(%r)' % self.variable


class LambdaNode(ASTNode):

    def __init__(self, parameter, body, param_type=None):
        self.parameter = parameter  # a string
        self.body = body  # an ast node
        self.param_type = param_type

    def __str__(self):

        if self.param_type is None:

            return "(\\%s. %s)" % (self.parameter, self.body)

        else:

            return "(\\%s : %s. %s)" \
                   % (self.parameter, self.param_type, self.body)

    def __repr__(self):
        return 'Lambda(%r, %r, %r)'\
               % (self.parameter, self.param_type, self.body)


class TrueNode(ASTNode):

    def __init__(self):
        pass

    def __str__(self):
        return 'true'

    def __repr__(self):
        return 'True'


class FalseNode(ASTNode):

    def __init__(self):
        pass

    def __str__(self):
        return 'false'

    def __repr__(self):
        return 'False'


class IfNode(ASTNode):
    """
    (if condition consequent alternative)
    """

    def __init__(self, condition, consequent, alternative):
        self.condition = condition
        self.consequent = consequent
        self.alternative = alternative

    def __str__(self):
        return "(if %s %s %s)" % (self.condition,
                                  self.consequent,
                                  self.alternative)

    def __repr__(self):
        return "If(%r, %r, %r)" % (self.condition,
                                   self.consequent,
                                   self.alternative)


class ApNode(ASTNode):

    def __init__(self, lhs, rhs):
        self.lhs = lhs  # An ast node
        self.rhs = rhs  # An ast node

    def __str__(self):
        return "(%s %s)" % (self.lhs, self.rhs)

    def __repr__(self):
        return 'Apply(%r, %r)' % (self.lhs, self.rhs)


class Primitive:
    """
    A enum value of Primitives.
    """

    def __init__(self, operator, param_types, return_type, func):
        """
        :param operator: operator string.
        :param param_types: a list of expected types of parameters.
        :param return_type: return type.
        :param func: the function that performs the operation.
        """

        self.operator = operator
        self.arity = len(param_types)
        self.param_types = param_types
        self.return_type = return_type
        self.func = func


class Primitives(Enum):
    """
    This is a enum for primitive operations.
    """

    Add = Primitive('+', [NumType(), NumType()], NumType(), lambda x, y: x + y)
    Sub = Primitive('-', [NumType(), NumType()], NumType(), lambda x, y: x - y)
    Mul = Primitive('*', [NumType(), NumType()], NumType(), lambda x, y: x * y)
    Div = Primitive('/', [NumType(), NumType()], NumType(), lambda x, y: x / y)
    Rem = Primitive('%', [NumType(), NumType()], NumType(), lambda x, y: x % y)
    Pow = Primitive('^', [NumType(), NumType()], NumType(), lambda x, y: x ** y)
    Add1 = Primitive('add1', [NumType()], NumType(), lambda x: x + 1)
    Sub1 = Primitive('sub1', [NumType()], NumType(), lambda x: x - 1)
    IsZero = Primitive('iszero', [NumType()], BoolType(), lambda x: x == 0)
    Gt = Primitive('>', [NumType(), NumType()], BoolType(), lambda x, y: x > y)
    Lt = Primitive('<', [NumType(), NumType()], BoolType(), lambda x, y: x < y)
    Eq = Primitive('=', [NumType(), NumType()], BoolType(), lambda x, y: x == y)
    Not = Primitive('not', [BoolType()], BoolType(), lambda x: not x)

    def __str__(self):
        return self.value.operator

    __repr__ = __str__

    @staticmethod
    def from_str(op):
        """
        Given an operator string, returns the corresponding enum value.

        Returns None if there is no corresponding enum value.
        """

        for x in Primitives:
            if x.value.operator == op:
                return x

        return None


class PrimApNode(ASTNode):

    def __init__(self, operator, operands):
        self.operator = operator
        self.operands = operands

    def __str__(self):
        return "(%s %s)" % (self.operator, ' '.join(map(str, self.operands)))

    def __repr__(self):
        return "PrimApply(%r, [%s])" % \
               (self.operator, ', '.join(map(repr, self.operands)))


class RecordNode(ASTNode):

    def __init__(self, names_values):
        """
        Given a list of tuples of names and values, construct a record node.
        """

        self.dict = dict(names_values)

    def __str__(self):
        return '{%s}' % ', '.join(['%s=%s' % (var, val)
                                   for var, val in self.dict.items()])

    def __repr__(self):
        return "Record(%r)" % list(self.dict.items())


class SelectionNode(ASTNode):
    """
    Select a field of a record.
    Syntax: expr.field
    """

    def __init__(self, expr, field):
        self.expr = expr
        self.field = field

    def __str__(self):
        return '%s.%s' % (self.expr, self.field)

    def __repr__(self):
        return "Selection(%r, %s)" % (self.expr, self.field)
