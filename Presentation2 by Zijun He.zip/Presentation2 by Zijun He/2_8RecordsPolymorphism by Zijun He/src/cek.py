"""
An interpreter implemented with CEK machine.
"""

from .ast import *
from numbers import Number
from .util import Env


class Closure:
    """
    A closure is composed of an AST and an environment.
    """

    def __init__(self, node, env):

        self.node = node
        self.env = env

    def __str__(self):

        return '(%s, %s)' % (self.node, self.env)

    __repr__ = __str__


class Cont:
    """
    Continuation
    """

    pass


class NullCont(Cont):
    """
    Null continuation represents `mt` in Chapter 7, Programming Languages and
    Lambda Calculi.
    """

    pass


class ArgCont(Cont):

    def __init__(self, rhs, next_cont):
        """
        Given a closure of the argument of a function application,
        construct a continuation.
        """

        self.rhs = rhs
        self.next_cont = next_cont


class FunCont(Cont):

    def __init__(self, lhs, next_cont):
        """
        Given an evaluated result (a closure) of the function of function
        application, construct a continuation.
        """

        self.lhs = lhs
        self.next_cont = next_cont


class IfCont(Cont):

    def __init__(self, consequent, alternative, next_cont):

        self.consequent = consequent  # a closure
        self.alternative = alternative  # a closure
        self.next_cont = next_cont


class PrimApCont(Cont):
    """
    This continuation corresponds to `opd` continuation in the book.
    """

    def __init__(self, operator, operands, rest_operands, next_cont):
        """
        :param operator:
        :param operands: the operands that are already evaluated.
        :param rest_operands: the rest operands that will be evaluated.
        """

        self.operator = operator
        self.rest_operands = rest_operands  # A list of closures
        self.operands = operands  # A list of closures
        self.next_cont = next_cont


class RecordCont(Cont):
    """
    This continuation is to save the to-be-evaluated record.
    """

    def __init__(self, field_names, fields, rest_fields, next_cont):
        """
        :param field_names: a list of field names.
        :param fields: a list of evaluated field values (closures).
        :param rest_fields: a list of not-yet-evaluated field expression closure
        """

        self.field_names = field_names
        self.fields = fields
        self.rest_fields = rest_fields
        self.next_cont = next_cont


class SelectionCont(Cont):
    """
    This continuation is to save the field name of field-selection expression.
    """

    def __init__(self, field_name, next_cont):

        self.field_name = field_name
        self.next_cont = next_cont


def ast_to_value(node):

    if isinstance(node, ConstNode):

        return node.value

    elif isinstance(node, TrueNode):

        return True

    elif isinstance(node, FalseNode):

        return False

    elif isinstance(node, RecordNode):

        return dict([(var, ast_to_value(c))
                     for var, c in node.dict.items()])

    else:

        return node


def value_to_ast(val):

    if isinstance(val, bool):

        return TrueNode() if val else FalseNode()

    elif isinstance(val, Number):

        return ConstNode(val)

    elif isinstance(val, dict):

        return RecordNode([(var, value_to_ast(v)) for var, v in val.items()])

    else:

        return val


def is_value(node):

    if isinstance(node, ConstNode) or \
            isinstance(node, TrueNode) or \
            isinstance(node, FalseNode) or \
            isinstance(node, LambdaNode):

        return True

    elif isinstance(node, RecordNode):

        return all([is_value(n) for n in node.dict.values()])

    else:

        return False


def run_cek(ast_node):
    """
    Given an AST of an ISWIM expression, evaluate it with the CEK machine and
    return the result.
    """

    closure = Closure(ast_node, Env())
    cont = NullCont()

    while True:

        if isinstance(closure.node, ApNode):

            cont = ArgCont(Closure(closure.node.rhs, closure.env), cont)
            closure = Closure(closure.node.lhs, closure.env)

        elif isinstance(closure.node, PrimApNode):

            operands = [Closure(operand, closure.env)
                        for operand in closure.node.operands]

            cont = PrimApCont(closure.node.operator, [], operands[1:], cont)
            closure = operands[0]

        elif isinstance(closure.node, VarNode):

            closure = closure.env.find(closure.node.variable)

            if closure is None:

                raise ValueError('Variable %s not found'
                                 % closure.node.variable)

        elif isinstance(closure.node, IfNode):

            cont = IfCont(Closure(closure.node.consequent, closure.env),
                          Closure(closure.node.alternative, closure.env),
                          cont)
            closure = Closure(closure.node.condition, closure.env)

        elif isinstance(closure.node, RecordNode) and \
                not is_value(closure.node):

            # If all fields of the record are values, we don't need to evaluate
            # the fields again.

            field_tuples = [i for i in closure.node.dict.items()]
            fields = [Closure(field, closure.env)
                      for _, field in field_tuples]

            cont = RecordCont([var for var, _ in field_tuples],
                              [],
                              fields[1:],
                              cont)
            closure = fields[0]

        elif isinstance(closure.node, SelectionNode):

            cont = SelectionCont(closure.node.field, cont)
            closure = Closure(closure.node.expr, closure.env)

        else:

            # Perform different action according to the continuation

            if isinstance(cont, ArgCont):

                new_closure = cont.rhs
                cont = FunCont(closure, cont.next_cont)
                closure = new_closure

            elif isinstance(cont, FunCont):

                func = cont.lhs.node

                if isinstance(func, LambdaNode):

                    closure = Closure(func.body,
                                      cont.lhs.env.extend(func.parameter,
                                                          closure))
                    cont = cont.next_cont

                else:

                    raise ValueError('Not a function: %s' % func)

            elif isinstance(cont, PrimApCont):

                if cont.rest_operands:

                    # Evaluate first operand of rest operands

                    cont.operands.append(closure)

                    closure = cont.rest_operands[0]
                    cont.rest_operands = cont.rest_operands[1:]

                else:

                    # All operands are evaluated

                    operator = cont.operator
                    operands = [ast_to_value(operand.node)
                                for operand
                                in cont.operands + [closure]]
                    closure = Closure(
                        value_to_ast(operator.value.func(*operands)),
                        Env())
                    cont = cont.next_cont

            elif isinstance(cont, IfCont):

                if isinstance(closure.node, TrueNode):

                    closure = cont.consequent
                    cont = cont.next_cont

                elif isinstance(closure.node, FalseNode):

                    closure = cont.alternative
                    cont = cont.next_cont

                else:

                    raise ValueError('If condition not boolean: %s'
                                     % closure.node)

            elif isinstance(cont, RecordCont):

                if cont.rest_fields:

                    # Evaluate first field of rest fields

                    cont.fields.append(closure)

                    closure = cont.rest_fields[0]
                    cont.rest_fields = cont.rest_fields[1:]

                else:

                    # All fields are evaluated, construct a record.

                    fields = [field.node for field in cont.fields + [closure]]

                    closure = Closure(RecordNode(zip(cont.field_names, fields)),
                                      Env())

                    cont = cont.next_cont

            elif isinstance(cont, SelectionCont):

                closure = Closure(closure.node.dict[cont.field_name],
                                  closure.env)
                cont = cont.next_cont

            elif isinstance(cont, NullCont):

                break

            else:

                raise AssertionError('Illegal state: (%s, %s)'
                                     % (closure, cont))

    return ast_to_value(closure.node)
