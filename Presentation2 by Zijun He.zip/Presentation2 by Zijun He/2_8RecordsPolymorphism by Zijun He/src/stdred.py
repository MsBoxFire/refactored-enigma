"""
An interpreter implemented with standard reduction.
"""

from .ast import *
from numbers import Number


def subst(node, var, val):
    """
    substitute the given value for all occurrences of the given variable in
    the given AST.

    :param node: the given AST
    :param var: the given variable
    :param val: the given value
    :return:
    """

    if isinstance(node, VarNode):

        if node.variable == var:

            return val

        else:

            return node

    elif isinstance(node, LambdaNode):

        if node.parameter == var:

            return node

        else:

            return LambdaNode(node.parameter, subst(node.body, var, val))

    elif isinstance(node, IfNode):

        return IfNode(subst(node.condition, var, val),
                      subst(node.consequent, var, val),
                      subst(node.alternative, var, val))

    elif isinstance(node, ApNode):

        return ApNode(subst(node.lhs, var, val), subst(node.rhs, var, val))

    elif isinstance(node, PrimApNode):

        return PrimApNode(node.operator,
                          [subst(operand, var, val)
                           for operand in node.operands])

    elif isinstance(node, RecordNode):

        return RecordNode([(var0, subst(val0, var, val))
                           for var0, val0 in node.dict.items()])

    elif isinstance(node, SelectionNode):

        return SelectionNode(subst(node.expr, var, val), node.field)

    else:

        return node


def value_to_ast(val):

    if isinstance(val, bool):

        return TrueNode() if val else FalseNode()

    elif isinstance(val, Number):

        return ConstNode(val)

    elif isinstance(val, dict):

        return RecordNode([(var, value_to_ast(v)) for var, v in val.items()])

    else:

        return val


def interp(node):

    if isinstance(node, ConstNode):

        return node.value

    elif isinstance(node, TrueNode):

        return True

    elif isinstance(node, FalseNode):

        return False

    elif isinstance(node, LambdaNode):

        return node

    elif isinstance(node, ApNode):

        lhs = value_to_ast(interp(node.lhs))
        rhs = value_to_ast(interp(node.rhs))

        if isinstance(lhs, LambdaNode):

            return interp(subst(lhs.body,
                                lhs.parameter,
                                rhs))

        else:

            raise ValueError('Lhs of function application is not function: %s'
                             % node.lhs)

    elif isinstance(node, PrimApNode):

        operands = [interp(operand)
                    for operand in node.operands]

        return node.operator.value.func(*operands)

    elif isinstance(node, IfNode):

        condition = interp(node.condition)

        if isinstance(condition, bool):

            if condition:

                return interp(node.consequent)

            else:

                return interp(node.alternative)

        else:

            raise ValueError('If condition is not bool: %s'
                             % node.condition)

    elif isinstance(node, RecordNode):

        return dict([(var, interp(expr)) for var, expr in node.dict.items()])

    elif isinstance(node, SelectionNode):

        dict1 = interp(node.expr)

        return dict1[node.field]

    else:

        raise ValueError('Invalid expression: %s' % node)


def run_stdred(ast_node):
    """
    Evaluate the given AST using standard reduction and return the result.
    Raises a ValueError if error.

    :return: a number, a boolean, a dict, or a LambdaNode
    """

    return interp(ast_node)
