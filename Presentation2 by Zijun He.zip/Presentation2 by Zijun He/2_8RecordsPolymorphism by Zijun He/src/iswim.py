from .parse import parse_untyped, parse_typed
from .cek import run_cek
from .typeinference import type_check as type_infer
from .typecheck import type_check


def run_untyped(expr):
    """
    Evaluate an untyped ISWIM expression and return the result.

    This interpreter supports records.

    :param expr: a string of untyped ISWIM expression.
    :return: The result may be a number, a boolean, a dict, or a LambdaNode.
    """

    return run_cek(parse_untyped(expr))


def run_type_inferred(expr):
    """
    Evaluate an ISWIM expression with types omitted, and return the result.

    The omitted types are automatically inferred and checked.

    This interpreter doesn't support records and row polymorphism.

    :param expr: a string of typed ISWIM expression with types omitted.
    :return: The result may be a number, a boolean, a dict, or a LambdaNode.
    """

    ast_node = parse_untyped(expr)

    type_infer(ast_node)

    return run_cek(ast_node)


def run_type_checked(expr):
    """
    Evaluate an ISWIM expression with types, and return the result.

    This interpreter supports records and row polymorphism.

    :param expr: a string of typed ISWIM expression.
    :return: The result may be a number, a boolean, a dict, or a LambdaNode.
    """

    ast_node = parse_typed(expr)

    type_check(ast_node)

    return run_cek(ast_node)
