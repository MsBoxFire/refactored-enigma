
def foldr(fn, x0, xs):
    """
    Returns fn(xs[0], fn(xs[1], ... fn(xs[-1], xs))).
    """

    for x in xs[::-1]:
        x0 = fn(x, x0)

    return x0


class Env:
    """
    An environment maps variables to values, where a value may be anything.

    This class is used in many modules.
    """

    def __init__(self):
        """
        Construct an empty environment.
        """

        self.dict = {}

    def extend(self, var, val):
        """
        Extend the environment with a variable mapping to a value, and return
        the new environment.
        """

        env = Env()
        env.dict = self.dict.copy()
        env.dict[var] = val

        return env

    def find(self, var):
        """
        Find corresponding value of the given variable in the environment.

        Returns None if not found.
        """

        return self.dict[var] if var in self.dict else None

    def __str__(self):

        return str(self.dict)

    __repr__ = __str__
