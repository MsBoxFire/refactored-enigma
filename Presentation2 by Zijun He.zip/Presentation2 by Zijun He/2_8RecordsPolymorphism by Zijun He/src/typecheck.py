
from .ast import *
from .util import Env as TypeEnv


def check(node, tenv):

    if isinstance(node, ConstNode):

        return NumType()

    elif isinstance(node, TrueNode) or isinstance(node, FalseNode):

        return BoolType()

    elif isinstance(node, VarNode):

        var_type = tenv.find(node.variable)

        if var_type is None:

            raise TypingError('Variable %s not found' % node.variable)

        else:

            return var_type

    elif isinstance(node, LambdaNode):

        body_type = check(node.body,
                          tenv.extend(node.parameter, node.param_type))

        return FuncType(node.param_type, body_type)

    elif isinstance(node, ApNode):

        func_type = check(node.lhs, tenv)
        arg_type = check(node.rhs, tenv)

        if isinstance(func_type, FuncType):

            if isinstance(func_type.lhs, RecordType) and \
                    isinstance(arg_type, RecordType):

                # When the parameter type of the function and the argument type
                # both are record type, the argument type must be subtype of
                # the parameter type. This is what is called row polymorphism.

                if arg_type.is_subtype_of(func_type.lhs):

                    return func_type.rhs

                else:

                    raise TypingError('Expecting subtype of record of type %s,'
                                      ' got %s' % (func_type.lhs, arg_type))

            elif func_type.lhs == arg_type:

                return func_type.rhs

            else:

                raise TypingError('Expecting argument of type %s for function"'
                                  '" of %s type, got %s'
                                  % (func_type.lhs, func_type, arg_type))

        else:

            raise TypingError('Not a function type: %s' % func_type)

    elif isinstance(node, PrimApNode):

        operand_types = [check(operand, tenv) for operand in node.operands]
        param_types = node.operator.value.param_types

        if len(operand_types) != len(param_types):

            raise TypingError('Arity mismatch for %s'
                              % node.operator.value.operator)

        for i in range(0, len(param_types)):

            if param_types[i] != operand_types[i]:

                raise TypingError('Expecting %s type for %s, got %s'
                                  % (param_types[i],
                                     node.operator.value.operator,
                                     operand_types[i]))

        return node.operator.value.return_type

    elif isinstance(node, IfNode):

        cond_type = check(node.condition, tenv)

        if not isinstance(cond_type, BoolType):

            raise TypingError('Expecting bool type for if condition, got %s'
                              % cond_type)

        conseq_type = check(node.consequent, tenv)
        alt_type = check(node.alternative, tenv)

        if isinstance(conseq_type, RecordType) and \
                isinstance(alt_type, RecordType):

            # If one branch is subtype of the other, return the supertype.

            if conseq_type.is_subtype_of(alt_type):

                return alt_type

            elif alt_type.is_subtype_of(conseq_type):

                return conseq_type

            else:

                raise TypingError('Two branches are not of subtype relation')

        elif conseq_type != alt_type:

            raise TypingError('Type mismatch for two branches of if')

        else:

            return conseq_type

    elif isinstance(node, RecordNode):

        names_types = [(var, check(expr, tenv))
                       for var, expr in node.dict.items()]

        return RecordType(names_types)

    elif isinstance(node, SelectionNode):

        ty = check(node.expr, tenv)

        if isinstance(ty, RecordType):

            if node.field in ty.dict:

                return ty.dict[node.field]

            else:

                raise TypingError("Record of type %s doesn't have the field %s"
                                  % (ty, node.field))

        else:

            raise TypingError('Expecting record type for field-selection, '
                              'got %s' % ty)

    else:

        raise AssertionError('Invalid AST: %s' % node)


def type_check(node):
    """
    Given an AST of an ISWIM expression, perform type checking and return
    the type of the expression.

    Raises a TypingError if typecheck failed.
    """

    return check(node, TypeEnv())
