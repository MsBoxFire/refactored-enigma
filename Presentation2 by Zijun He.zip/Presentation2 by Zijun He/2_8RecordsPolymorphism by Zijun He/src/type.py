
class TypingError(RuntimeError):

    def __init__(self, message):
        super(TypingError, self).__init__(message)


class Type:

    def __eq__(self, other):
        return type(self) == type(other) and self.__dict__ == other.__dict__

    def free_vars(self):
        """
        Get free variables of this type.

        :return a list of variables. The list may contains duplicate variables.
        """
        pass

    def subst(self, var0, type1):
        """
        Substitue type1 for all occurrences of the type variable var0 and return
        the substituted type.

        Doesn't modify the original type.
        """
        pass


class BoolType(Type):

    def subst(self, var0, type1):
        return self

    def free_vars(self):
        return []

    def __str__(self):
        return 'bool'

    __repr__ = __str__


class NumType(Type):

    def subst(self, var0, type1):
        return self

    def free_vars(self):
        return []

    def __str__(self):
        return 'num'

    __repr__ = __str__


class FuncType(Type):
    """
    Function type.
    """

    def __init__(self, lhs, rhs):
        self.lhs = lhs
        self.rhs = rhs

    def free_vars(self):
        return self.lhs.free_vars() + self.rhs.free_vars()

    def subst(self, var0, type1):
        return FuncType(self.lhs.subst(var0, type1),
                        self.rhs.subst(var0, type1))

    def __str__(self):
        return '(%s -> %s)' % (self.lhs, self.rhs)

    __repr__ = __str__


class RecordType(Type):
    """
    Record type.
    """

    def __init__(self, names_types):
        """
        Given a list of tuples of names and types, construct a record type.
        """

        self.dict = dict(names_types)

    def is_subtype_of(self, other):
        """
        Given another record type, returns if this record type is a subtype of
        that type.

        The order of fields doesn't matter in determining the subtyping
        relation.
        """

        return set(other.dict).issubset(set(self.dict)) and \
            all([self.dict[var] == other.dict[var]
                 for var in other.dict.keys()])

    def free_vars(self):

        return sum([ty.free_vars() for _, ty in self.dict.items()], [])

    def subst(self, var0, type1):

        return RecordType([(var, ty.subst(var0, type1))
                           for var, ty in self.dict.items()])

    def __str__(self):
        return '<%s>' % ', '.join(['%s: %s' % i for i in self.dict.items()])

    __repr__ = __str__


class VarType(Type):
    """
    Type variable.
    """

    def __init__(self, var):
        self.var = var

    def free_vars(self):
        return [self.var]

    def subst(self, var0, type1):
        if var0 == self.var:
            return type1
        else:
            return self

    def __str__(self):
        return self.var

    __repr__ = __str__


def type_equal(type1, type2):
    """
    Checking whether the two given types are equal, ignoring the difference of
    type variables. E.g., (a1 -> a1) is equal to (a2 -> a2) in this regard.

    Doesn't check polymorphism type.

    :return: boolean
    """

    def equal(ty1, ty2, var_map):
        """
        :param ty1: type1
        :param ty2: type2
        :param var_map: a dict the maps the type variables in type1 to that in
                        type2.
        :return: boolean
        """

        if isinstance(ty1, VarType) and isinstance(ty2, VarType):

            if ty1.var in var_map:

                return var_map[ty1.var] == ty2.var

            else:

                var_map[ty1.var] = ty2.var

                return True

        elif isinstance(ty1, FuncType) and isinstance(ty2, FuncType):

            return equal(ty1.lhs, ty2.lhs, var_map) and \
                   equal(ty1.rhs, ty2.rhs, var_map)

        else:

            return ty1 == ty2

    return equal(type1, type2, {})
