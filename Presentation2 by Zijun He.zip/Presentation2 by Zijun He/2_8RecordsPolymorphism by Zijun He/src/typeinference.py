from .ast import *
from .util import Env as TypeEnv


class TypeRelation:

    def __init__(self, lhs, rhs):
        """
        :param lhs: The type of the left-hand side of the relation.
        :param rhs: The type of the right-hand side of the relation.
        """

        self.lhs = lhs
        self.rhs = rhs

    def subst(self, var0, type1):
        """
        Substitute type1 for all occurrences of the type variable var0 in lhs
        and rhs.
        """

        self.lhs = self.lhs.subst(var0, type1)
        self.rhs = self.rhs.subst(var0, type1)

    def __str__(self):
        return '%s = %s' % (self.lhs, self.rhs)

    __repr__ = __str__


class InferredTypes:
    """
    The result of unification, which stores the inferred types for type
    variables.
    """

    def __init__(self):

        """
        A dict that stores type variables and the corresponding types.
        """
        self.type_map = {}

    def put_type(self, var, type1):
        """
        Add inferred type for the given type variable.
        """

        self.type_map[var] = type1

    def get_type(self, type1):
        """
        If the given type is a type variable, return the inferred type of the
        type variable after substitution.

        Otherwise, return the new type after substitution.
        """

        if isinstance(type1, VarType):

            if type1.var in self.type_map:

                type1 = self.type_map[type1.var]

            else:

                return type1

        return self.subst(type1)

    def subst(self, type1):
        """
        Substitute the corresponding types for all type variables in the given
        type.

        :return: the new type after substitution.
        """

        fvars = list(set(type1.free_vars()))

        # Keep substituting until there are no type variables that are in
        # type_map.
        while fvars:

            fv = fvars.pop()

            if fv in self.type_map:

                subst_type = self.type_map[fv]

                type1 = type1.subst(fv, subst_type)

                # Add the type variables of the substitute
                fvars.extend(subst_type.free_vars())

        return type1

    def __str__(self):
        return str(self.type_map)

    __repr__ = __str__


def type_check(node):
    """
    Perform typechecking and type inference on the given ISWIM expression.

    If fails, a TypingError is raised.

    :param node: the AST of an ISWIM expression.
    :return: the inferred type of the given expression.
    """

    """
    Used to generate fresh type variables.
    """
    var_counter = 0

    def new_var():
        """
        Generate a fresh type variable
        """

        nonlocal var_counter
        var_counter += 1
        return 'a%s' % var_counter

    def gen_constraints(n, tenv):
        """
        Generate type relations for the given expression.

        :param n: The AST of an ISWIM expression
        :param tenv: type environment
        :return: the type of the given expression, a list of generated
                 constraints, and a list of generated type variables.
        """

        if isinstance(n, ConstNode):

            return NumType(), [], []

        elif isinstance(n, TrueNode) or isinstance(n, FalseNode):

            return BoolType(), [], []

        elif isinstance(n, VarNode):

            type1 = tenv.find(n.variable)

            if type1 is None:

                raise TypingError('Variable %s not found' % n.variable)

            return type1, [], []

        elif isinstance(n, LambdaNode):

            var1 = new_var()

            param_type = VarType(var1)

            body_tenv = tenv.extend(n.parameter, param_type)

            return_type, body_cons, body_tvars = \
                gen_constraints(n.body, body_tenv)

            constraints1 = body_cons

            tvars1 = body_tvars + [var1]

            return FuncType(param_type, return_type), constraints1, tvars1

        elif isinstance(n, ApNode):

            lhs_type, lhs_cons, lhs_tvars = gen_constraints(n.lhs, tenv)

            rhs_type, rhs_cons, rhs_tvars = gen_constraints(n.rhs, tenv)

            var1 = new_var()

            return_type = VarType(var1)

            type_relation = TypeRelation(lhs_type,
                                         FuncType(rhs_type, return_type))

            constraints1 = lhs_cons + rhs_cons + [type_relation]

            tvars1 = lhs_tvars + rhs_tvars + [var1]

            return return_type, constraints1, tvars1

        elif isinstance(n, PrimApNode):

            param_types = n.operator.value.param_types
            return_type = n.operator.value.return_type

            if len(param_types) != len(n.operands):

                raise TypingError('Arity mismatch for %s'
                                  % n.operator.value.operator)

            arg_types = []
            constraints1 = []
            tvars1 = []

            for arg in n.operands:

                arg_type, arg_cons, arg_tvars = gen_constraints(arg, tenv)

                arg_types.append(arg_type)

                constraints1 += arg_cons

                tvars1 += arg_tvars

            arg_type_relations = map(TypeRelation,
                                     arg_types,
                                     param_types)

            constraints1.extend(arg_type_relations)

            return return_type, constraints1, tvars1

        elif isinstance(n, IfNode):

            cond_type, cond_cons, cond_tvars = \
                gen_constraints(n.condition, tenv)

            conseq_type, conseq_cons, conseq_tvars = \
                gen_constraints(n.consequent, tenv)

            alt_type, alt_cons, alt_tvars = \
                gen_constraints(n.alternative, tenv)

            cond_type_relation = TypeRelation(cond_type,
                                              BoolType())

            # The types of the two branches of `if` expression must be identical
            branch_type_relation = TypeRelation(conseq_type,
                                                alt_type)

            constraints1 = cond_cons + conseq_cons + alt_cons + \
                [cond_type_relation, branch_type_relation]

            tvars1 = cond_tvars + conseq_tvars + alt_tvars

            return conseq_type, constraints1, tvars1

        else:

            raise ValueError('Invalid AST node: ' + str(n))

    def unification(constraints1):
        """
        Perform unification on the constraint list.

        All polymorphic types are eliminated at constraint generation phase,
        so no polymorphic types are handled at unification phase.

        :return: InferredTypes.
        """

        # print(constraints1)

        inferred_types = InferredTypes()

        while constraints1:

            relation = constraints1.pop()

            if isinstance(relation.lhs, VarType):

                if relation.lhs == relation.rhs:

                    # Lhs and rhs are the same type variable, skip this relation
                    pass

                elif relation.lhs.var in relation.rhs.free_vars():

                    raise TypingError(
                        'Cannot infer infinite type for %s = %s'
                        % (relation.lhs, relation.rhs))

                else:

                    for rel in constraints1:
                        rel.subst(relation.lhs.var, relation.rhs)

                    inferred_types.put_type(relation.lhs.var, relation.rhs)

            elif isinstance(relation.rhs, VarType):

                if relation.lhs == relation.rhs:

                    # Lhs and rhs are the same type variable, skip this relation
                    pass

                elif relation.rhs.var in relation.lhs.free_vars():

                    raise TypingError(
                        'Cannot infer infinite type for %s = %s'
                        % (relation.lhs, relation.rhs))

                else:

                    for rel in constraints1:
                        rel.subst(relation.rhs.var, relation.lhs)

                    inferred_types.put_type(relation.rhs.var, relation.lhs)

            elif isinstance(relation.lhs, FuncType) and \
                    isinstance(relation.rhs, FuncType):

                func_type1 = relation.lhs
                func_type2 = relation.rhs

                constraints1.extend(
                    [TypeRelation(func_type1.lhs, func_type2.lhs),
                     TypeRelation(func_type1.rhs, func_type2.rhs)])

            elif relation.lhs != relation.rhs:

                raise TypingError('Type mismatch: %s != %s' %
                                  (relation.lhs, relation.rhs))

        # print(inferred_types)

        return inferred_types

    type_, constraints, tvars = gen_constraints(node, TypeEnv())

    types = unification(constraints)

    # print(type_)

    return types.get_type(type_)
