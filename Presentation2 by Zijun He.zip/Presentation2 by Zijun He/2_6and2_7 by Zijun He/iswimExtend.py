# -*- coding: utf-8 -*-
import mygc as gc


# Explain:
# Use letters and constructors to represent types, such as
# N -- Integer type
# N - > N is a lambda type, the parameter is N (integer), return value N is an integer as well
# data type defination, only integer is supported now
# example for lambda expression type :
#   lambda x:N. x + 1  type: N->N 
INT_TYPE = 'N' # integer type

manager = gc.Manager(100)

# Basic math calculate
# manage memory with mutation
def add1(x):
    ''' add 1 operation
    '''
    val1 = manager.active(x, -1)
    val2 = manager.active(1, -1)
    result = manager.active(manager.get_value(
        val1) + manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return result


def sub1(x):
    ''' sub 1 operation
    '''
    val1 = manager.active(x, -1)
    val2 = manager.active(1, -1)
    result = manager.active(manager.get_value(
        val1) - manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return result


def add(x, y):
    ''' add operation
    '''
    val1 = manager.active(x, -1)
    val2 = manager.active(y, -1)
    result = manager.active(manager.get_value(
        val1) + manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return result


def sub(x, y):
    ''' sub operation
    '''
    val1 = manager.active(x, -1)
    val2 = manager.active(y, -1)
    result = manager.active(manager.get_value(
        val1) - manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return result


def mul(x, y):
    ''' mul operation
    '''
    val1 = manager.active(x, -1)
    val2 = manager.active(y, -1)
    result = manager.active(manager.get_value(
        val1) * manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return result


def exp(x, y):
    ''' power operation
    '''
    val1 = manager.active(x, -1)
    val2 = manager.active(y, -1)
    result = manager.active(manager.get_value(
        val1) ** manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return result

def iszero(x):
    '''check if lambda expression 'x' is defination of 0
       return bool defination of TRUE or FALSE
    '''
    if x == 0:

        return Lambda(Variable('x', INT_TYPE), Lambda(Variable('y', INT_TYPE), Variable('x', INT_TYPE)))

    else:

        return Lambda(Variable('x', INT_TYPE), Lambda(Variable('y', INT_TYPE), Variable('y', INT_TYPE)))


class ISWIM:
    pass


class Variable(ISWIM):
    def __init__(self, name, vtype):
        self.vtype = vtype
        self.name = name

    def __str__(self):

        return self.name

    __repr__ = __str__


class Constant(ISWIM):
    def __init__(self, const, vtype):
        self.const = const
        self.vtype = vtype # value type

    def __str__(self):

        return str(self.const)

    __repr__ = __str__


class Lambda(ISWIM):
    def __init__(self, parameter, body):
        """
            :param parameter: a Variable
            :return:
        """
        self.parameter = parameter
        self.body = body

    def apply(self, v):
        return replace(self.body, self.parameter, v)

    def inference_type(self):
        '''
            type of lambda expression
        '''
        return self.parameter.vtype + '->' + type_inference(self.body)

    def check_type(self):
        '''
            check if type of lambda expression is correct
        '''
        if not isinstance(self.parameter, Variable):
            return False
        return check_type(self.body)

    def __str__(self):
        '''stringify
        '''
        return "(lambda (%s) (%s))" % (str(self.parameter), str(self.body))

    __repr__ = __str__


class Apply(ISWIM):
    def __init__(self, M1, M2):

        self.M1 = M1

        self.M2 = M2

    def reduce(self):
        '''calling lambda expression 
        '''
        return self.M1.apply(self.M2)
    
    def check_type(self):
        # the 1st argv of Apply must be Lambda or Variable
        if not any([isinstance(self.M1, Variable), isinstance(self.M1, Lambda)]):
            return False
        return True

    def __str__(self):
        '''stringify
        '''
        return "(apply (%s) (%s))" % (str(self.M1), str(self.M2))

    __repr__ = __str__


class PrimitiveApply(ISWIM):
    def __init__(self, name, args):

        self.name = name

        if name == "add":

            self.op = add

        elif name == "add1":

            self.op = add1

        elif name == "sub1":

            self.op = sub1

        elif name == "sub":

            self.op = sub

        elif name == "mul":

            self.op = mul

        elif name == "exp":

            self.op = exp

        else:

            print("invalid name")

        self.args = args

    def __str__(self):
        '''stringify
        '''
        return "(%s (%s))" % (str(self.name), str(self.args))

    def inference_type(self):
        '''inference type of PrimitiveApply result
        '''
        type_list = list(map(lambda x: type_inference(x), self.args))
        # handle some operation of math
        if self.op in [add, add1, sub, sub1, mul, exp]:
            if INT_TYPE in type_list:
                return INT_TYPE
            else:
                # another lower level type
                return INT_TYPE
        else:
            # another operation
            return INT_TYPE

    def check_type(self):
        '''check type of PrimitiveApply argvs is correct
        '''
        type_list = list(map(lambda x: type_inference(x), self.args))

        # check there are complex-type argvs in PrimitiveApply
        if not all([('->' not in vtype) for vtype in type_list]):
            return False
        if self.op in [add, add1, sub, sub1, mul, exp]:
            numeric_type = [INT_TYPE]
            if all([(vtype in numeric_type) for vtype in type_list]):
                return True
            else:
                return False
        # another operation
        return False

    __repr__ = __str__


def isValue(e):
    '''check if expression is value type
    '''
    return isinstance(e, Constant) or isinstance(e, Variable) or isinstance(e, Lambda)


def replace(M,  x, v):
    '''replace variable by value
    '''
    if isinstance(M, Variable):

        if M.name == x.name:

            return v

        else:
            return M

    if isinstance(M, Constant):

        return M

    if isinstance(M, Apply):

        return Apply(replace(M.M1, x, v), replace(M.M2, x, v))

    if isinstance(M, PrimitiveApply):

        newArgs = [replace(arg, x, v) for arg in M.args]

        return PrimitiveApply(M.name, newArgs)

    if isinstance(M, Lambda):

        return Lambda(M.parameter, replace(M.body, x, v))

    print("error in replace")

    return M


def check_type(e):
    '''check if type of e is correct
       maybe include recursion in methods
    '''
    if isinstance(e, Constant):
        return True

    if isinstance(e, Variable):
        return True

    if isinstance(e, Lambda):
        return e.check_type()

    if isinstance(e, Apply):
        return e.check_type()

    if isinstance(e, PrimitiveApply):
        return e.check_type()


def type_inference(e):
    '''type inference of expression
    '''
    if isinstance(e, Constant):
        return e.vtype

    if isinstance(e, Variable):
        return e.vtype

    if isinstance(e, Lambda):
        return e.inference_type()

    if isinstance(e, Apply):
        if isValue(e.M2):
            return type_inference(e.reduce())
        else:
            e.M2 = interpret(e.M2)
            return type_inference(e)

    if isinstance(e, PrimitiveApply):
        return e.inference_type()


def interpret(e):

    if isinstance(e, Constant):

        return e

    if isinstance(e, Variable):

        return e

    if isinstance(e, Lambda):

        return e

    if isinstance(e, Apply):

        if isValue(e.M2):

            return interpret(e.reduce())

        else:

            e.M2 = interpret(e.M2)

            return interpret(e)

    if isinstance(e, PrimitiveApply):

        for i in range(len(e.args)):

            if not isValue(e.args[i]):

                e.args[i] = interpret(e.args[i])

                return interpret(e)

        cs = [t.const for t in e.args]

        # free memory unit in buffer by manager
        res = e.op(*cs)
        c_res = Constant(manager.get_value(res), INT_TYPE)
        manager.deactive(res)

        return c_res

def run(e):
    check_flag = check_type(e)
    print('Check Type : ', 'Passed' if check_flag else 'Not passed')
    if check_flag:
        print('Value of lambda expression:', interpret(e))
        print('Type Inference of return lambda expression:', type_inference(e))

def test():
    print('***********************Test case 1****************************')
    print("run add 1 2")
    run(PrimitiveApply("add",  [Constant(1, INT_TYPE), Constant(2, INT_TYPE)]))
    print('**************************************************************\n\n')

    print('***********************Test case 2****************************')
    print("run ((Lambda xy. (+ x y)) 10) ")
    run(Apply(Lambda(Variable("x", INT_TYPE), Lambda(Variable("y", INT_TYPE), PrimitiveApply(
        "add", [Variable("x", INT_TYPE), Variable("y", INT_TYPE)]))), Constant(10, INT_TYPE)))
    print('**************************************************************\n\n')

    print('***********************Test case 3****************************')
    print("run exercise 5.1 example")

    e1 = Lambda(Variable('w', INT_TYPE), PrimitiveApply(
        'sub', [Apply(Variable('w', INT_TYPE),  Constant(1, INT_TYPE)), Constant(5, INT_TYPE)]))

    e2 = Lambda(Variable('x', INT_TYPE),  Apply(
        Variable('x', INT_TYPE), Constant(10, INT_TYPE)))

    print("e3 = lambda y. (lambda z. z + y)")
    e3 = Lambda(Variable('y', INT_TYPE),  Lambda(Variable('z', INT_TYPE),  PrimitiveApply(
        'add',  [Variable('z', INT_TYPE),  Variable('y', INT_TYPE)])))

    e4 = Apply(e2,  e3)
    run(e4)

    e5 = Apply(e1, e4)
    run(e5)

    print('**************************************************************\n\n')

    print('***********************Test case 4****************************')
    print("run (Lambda xy. (+ x y))")
    run(Lambda(Variable("x", INT_TYPE), Lambda(Variable("y", INT_TYPE), PrimitiveApply(
        "add", [Variable("x", INT_TYPE), Variable("y", INT_TYPE)]))))
    print('**************************************************************\n\n')

    print('************Test case 5(Type Check Error Case)***************')
    print("run (Lambda xy. (+ (Lambda z. z) y))")
    run(Lambda(Variable("x", INT_TYPE), Lambda(Variable("y", INT_TYPE), PrimitiveApply(
        "add", [Lambda(Variable("z", INT_TYPE), Variable("z", INT_TYPE)), Variable("y", INT_TYPE)]))))
    print('**************************************************************\n\n')


if __name__ == '__main__':
    test()
