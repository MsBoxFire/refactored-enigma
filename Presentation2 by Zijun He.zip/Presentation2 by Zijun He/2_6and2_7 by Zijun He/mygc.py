# -*- coding: utf-8 -*-
import sys
from collections import deque

heap, root, rest = [], [], []

def chunk2dict(chunk):
    
    ret = {}
    ret["is_mark"] = chunk[0]
    ret["next"] = chunk[1]
    ret["child"] = chunk[2]
    ret["value"] = chunk[3]
    return ret

def dict2chunk(dic):
    
    chunk = []
    chunk.append(dic["is_mark"])
    chunk.append(dic["next"])
    chunk.append(dic["child"])
    chunk.append(dic["value"])
    return chunk

def get_chunk_info(start):
    
    global heap
    return chunk2dict(heap[start: start + 4])

def set_chunk_info(start, dic):
    
    global heap
    chunk = dict2chunk(dic)
    for i in range(4):
        heap[start + i] = chunk[i]

def mark_chunk(start):
    
    global heap
    dic = get_chunk_info(start)
    dic["is_mark"] = 1
    chunk = dict2chunk(dic)
    for i in range(4):
        heap[start + i] = chunk[i]

def unmark_chunk(start):
    
    global heap
    dic = get_chunk_info(start)
    dic["is_mark"] = 0
    chunk = dict2chunk(dic)
    for i in range(4):
        heap[start + i] = chunk[i]

class GC(object):
    def __init__(self):
        pass

    @staticmethod
    def pick_avail_heap(rest):
        
        start, chunk = None, None
        for item in rest:
            if (item[1] - item[0]) >= 4:
                start, chunk = item[0], item
                break
        if start == None:
            return -1
        else:
            rest.remove(chunk)
            if (chunk[1] - chunk[0]) != 4:
                rest.append((chunk[0] + 4, chunk[1]))
                rest.sort(key=lambda x: x[0])
            return chunk[0]

    @staticmethod
    def allocate(heap, root, rest, value, parent):
        if parent == -1:
            
            ptr = GC.pick_avail_heap(rest)
            if ptr != -1:
                
                new_info = get_chunk_info(ptr)
                new_info["child"] = -1
                new_info["next"] = -1
                new_info["is_mark"] = 0
                new_info["value"] = value
                set_chunk_info(ptr, new_info)
                root.append(ptr)
            return ptr
        else:
            print(parent)
            
            quene = deque(root)
            while len(quene) != 0:
                idx = quene.popleft()
                if idx != -1:
                    quene.append(get_chunk_info(idx)["child"])
                    quene.append(get_chunk_info(idx)["next"])
                if idx == parent:
                    ptr = GC.pick_avail_heap(rest)
                    if ptr != -1:
                        
                        if(get_chunk_info(idx)["child"] == -1):
                            
                            p_info = get_chunk_info(idx)
                            p_info["child"] = ptr
                            set_chunk_info(idx, p_info)
                        else:
                            idx = get_chunk_info(idx)["child"]
                            
                            while(get_chunk_info(idx)["next"] != -1):
                                idx = get_chunk_info(idx)["next"]
                            p_info = get_chunk_info(idx)
                            p_info["next"] = ptr
                            set_chunk_info(idx, p_info)
     
                        new_info = get_chunk_info(ptr)
                        new_info["child"] = -1
                        new_info["next"] = -1
                        new_info["is_mark"] = 0
                        new_info["value"] = value
                        set_chunk_info(ptr, new_info)
                    return ptr
            return -1


    @staticmethod
    def free(ptr):
        
        global root
        if ptr in root:
           
            root.remove(ptr)
        else:
           
            quene = deque(root)
            while len(quene) != 0:
                idx = quene.popleft()
                info = get_chunk_info(idx)
                n = info["next"]
                c = info["child"]
                if c == ptr:
                    
                    info["child"] = -1
                    set_chunk_info(idx, info)
                    return
                if n == ptr:
                    
                    info["next"] = get_chunk_info(get_chunk_info(idx)["next"])["next"]
                    set_chunk_info(idx, info)
                    return


    @staticmethod
    def mark():
        
        global heap, root
        quene = deque(root)
        while len(quene) != 0:
            idx = quene.popleft()
            mark_chunk(idx)
            info = get_chunk_info(idx)
            n, c = info["next"], info["child"]
            if n != -1:
                quene.append(n)
            if c != -1:
                quene.append(c)

    @staticmethod
    def sweep():
   
        global heap, rest
        idx = 0
        while idx < len(heap):
            info = get_chunk_info(idx)
            if info["is_mark"] == 0:
                rest.append((idx, idx + 4))
            else:
                unmark_chunk(idx)
            idx += 4
        
        
        rest = list(set(rest))
        new_rest = set()
        sub = ()
        for item in sorted(rest, key=lambda x:x[0]):
            if sub == ():
                sub = item
            else:
                if sub[1] == item[0]:
                    sub = (sub[0], item[1])
                else:
                    new_rest.add(sub)
                    sub = item
        if sub != ():
            new_rest.add(sub)
        rest = list(new_rest)
        
    

class Manager(object):
    def __init__(self, heap_size=100):
       
        global heap, root, rest
        heap = [-1 for _ in range(heap_size)]
        root = []
        rest = [(0, heap_size)]
        self.gc = GC()
    
    def active(self, value, parent):
        
        ptr = self.gc.allocate(heap, root, rest, value, parent)
        if ptr == -1:
            
            print("Memory full, garbage collect automatically ~ ", file=sys.stderr)
            self.gc_exec()
        else:
            return ptr
        
        ptr = self.gc.allocate(heap, root, rest, value, parent)
        if ptr != -1:
            return ptr
        else:
            print("Allocate memory failed ~ ", file=sys.stderr)
            exit(1)
        

    def deactive(self, ptr):
       
        self.gc.free(ptr)

    def gc_exec(self):
        
        self.gc.mark()
        self.gc.sweep()
        print("GC success ~ Available memory =>", rest, file=sys.stderr)

    def get_value(self, ptr):
        
        return get_chunk_info(ptr)["value"]

    def print_heap(self, hint):
       
        global heap, rest, rest
        print(hint)
        print("Root => ", sorted(root))
        print("Rest => ", sorted(rest, key=lambda x:x[0]))
        idx = 0
        while(idx < len(heap)):
            dic = chunk2dict(heap[idx:idx+4])
            print("Chunk Ptr " + str(idx) + "  is_mark: " + str(dic["is_mark"]) + " next: " + str(dic["next"]) + " child: " + str(dic["child"]) + " val: " + str(dic["value"]))
            idx += 4
        print("\n\n")


if __name__ == "__main__":
    manager = Manager(100)

    
    val_p1 = manager.active(1, -1)

    
    val_p1 = manager.active(2, val_p1)

    
    for _ in range(23):
        manager.active(_, -1)

    
    manager.print_heap("Insert 25 val, Heap should be full now >>>")

    
    manager.deactive(8)
    manager.deactive(12)
    manager.deactive(20)
    manager.print_heap("Free 3rd 4rd 6th chunk without gc >>>")

    
    manager.gc_exec()
    manager.print_heap("GC >>>")

   
    manager.active(21, val_p1)
    manager.active(22, val_p1)
    manager.active(23, val_p1)
    manager.print_heap("Insert 3 new val >>>")

   
    manager.deactive(16)
    manager.deactive(20)
    manager.deactive(28)
    manager.print_heap("Free 5nd 6rd 8th chunk without gc >>>")

    
    manager.active(72, val_p1)
    manager.active(73, val_p1)
    manager.active(76, val_p1)
    manager.print_heap("Try to insert 3 new val >>>")
