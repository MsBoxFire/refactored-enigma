# -*- coding: utf-8 -*-
import sys
from collections import deque

heap, root, rest = [], [], []

def chunk2dict(chunk):
    # Change it to dict
    ret = {}
    ret["is_mark"] = chunk[0]
    ret["next"] = chunk[1]
    ret["child"] = chunk[2]
    ret["value"] = chunk[3]
    return ret

def dict2chunk(dic):
    # Converting dict to a specified format memory block
    chunk = []
    chunk.append(dic["is_mark"])
    chunk.append(dic["next"])
    chunk.append(dic["child"])
    chunk.append(dic["value"])
    return chunk

def get_chunk_info(start):
    # Gets the information of the memory block at the specified
    #location and returns the dict format
    global heap
    return chunk2dict(heap[start: start + 4])

def set_chunk_info(start, dic):
    # Update the information of the memory block at the
    #specified location using Dict
    global heap
    chunk = dict2chunk(dic)
    for i in range(4):
        heap[start + i] = chunk[i]

def mark_chunk(start):
    # Mark the memory block as reserved(1)
    global heap
    dic = get_chunk_info(start)
    dic["is_mark"] = 1
    chunk = dict2chunk(dic)
    for i in range(4):
        heap[start + i] = chunk[i]

def unmark_chunk(start):
    # Mark the memory block as recycled(0)
    global heap
    dic = get_chunk_info(start)
    dic["is_mark"] = 0
    chunk = dict2chunk(dic)
    for i in range(4):
        heap[start + i] = chunk[i]

class GC(object):
    def __init__(self):
        pass

    @staticmethod
    def pick_avail_heap(rest):
        # Find available memory from heap and return the first byte location
        start, chunk = None, None
        for item in rest:
            if (item[1] - item[0]) >= 4:
                start, chunk = item[0], item
                break
        if start == None:
            return -1
        else:
            rest.remove(chunk)
            if (chunk[1] - chunk[0]) != 4:
                rest.append((chunk[0] + 4, chunk[1]))
                rest.sort(key=lambda x: x[0])
            return chunk[0]

    @staticmethod
    def allocate(heap, root, rest, value, parent):
        if parent == -1:
            # Allocate the memory space of root
            ptr = GC.pick_avail_heap(rest)
            if ptr != -1:
                # Update content to new block
                new_info = get_chunk_info(ptr)
                new_info["child"] = -1
                new_info["next"] = -1
                new_info["is_mark"] = 0
                new_info["value"] = value
                set_chunk_info(ptr, new_info)
                root.append(ptr)
            return ptr
        else:
            print(parent)
            # Allocate the memory of the child node of the object
            quene = deque(root)
            while len(quene) != 0:
                idx = quene.popleft()
                if idx != -1:
                    quene.append(get_chunk_info(idx)["child"])
                    quene.append(get_chunk_info(idx)["next"])
                if idx == parent:
                    ptr = GC.pick_avail_heap(rest)
                    if ptr != -1:
                        # Update pointer links between objects
                        if(get_chunk_info(idx)["child"] == -1):
                            # Insert directly into child nodes
                            p_info = get_chunk_info(idx)
                            p_info["child"] = ptr
                            set_chunk_info(idx, p_info)
                        else:
                            idx = get_chunk_info(idx)["child"]
                            # Insert into the last brother of the child
                            while(get_chunk_info(idx)["next"] != -1):
                                idx = get_chunk_info(idx)["next"]
                            p_info = get_chunk_info(idx)
                            p_info["next"] = ptr
                            set_chunk_info(idx, p_info)
                        # Update content to new application block
                        new_info = get_chunk_info(ptr)
                        new_info["child"] = -1
                        new_info["next"] = -1
                        new_info["is_mark"] = 0
                        new_info["value"] = value
                        set_chunk_info(ptr, new_info)
                    return ptr
            return -1


    @staticmethod
    def free(ptr):
        # Release memory at specified locations for recycling
        global root
        if ptr in root:
            # Recycle root memory and delete root pointer directly
            root.remove(ptr)
        else:
            # need search tree
            quene = deque(root)
            while len(quene) != 0:
                idx = quene.popleft()
                info = get_chunk_info(idx)
                n = info["next"]
                c = info["child"]
                if c == ptr:
                    # The node to be deleted is the child node,
                    # and the pointer can be deleted directly.
                    info["child"] = -1
                    set_chunk_info(idx, info)
                    return
                if n == ptr:
                    #The node to be deleted is a sibling node,
                    # and the pointer points to the next sibling of the node.
                    info["next"] = get_chunk_info(get_chunk_info(idx)["next"])["next"]
                    set_chunk_info(idx, info)
                    return


    @staticmethod
    def mark():
        # In the mark phase, the is_mark of all accessible
        # objects are set to 1
        global heap, root
        quene = deque(root)
        while len(quene) != 0:
            idx = quene.popleft()
            mark_chunk(idx)
            info = get_chunk_info(idx)
            n, c = info["next"], info["child"]
            if n != -1:
                quene.append(n)
            if c != -1:
                quene.append(c)

    @staticmethod
    def sweep():
        # In the sweep phase, the memory of all inaccessible
        # objects is deleted and the address of the recycling memory is recorded.
        global heap, rest
        idx = 0
        while idx < len(heap):
            info = get_chunk_info(idx)
            if info["is_mark"] == 0:
                rest.append((idx, idx + 4))
            else:
                unmark_chunk(idx)
            idx += 4
        
        # Merge fragmented memory
        rest = list(set(rest))
        new_rest = set()
        sub = ()
        for item in sorted(rest, key=lambda x:x[0]):
            if sub == ():
                sub = item
            else:
                if sub[1] == item[0]:
                    sub = (sub[0], item[1])
                else:
                    new_rest.add(sub)
                    sub = item
        if sub != ():
            new_rest.add(sub)
        rest = list(new_rest)
        
    

class Manager(object):
    def __init__(self, heap_size=100):
        # Initialization of manager
        global heap, root, rest
        heap = [-1 for _ in range(heap_size)]
        root = []
        rest = [(0, heap_size)]
        self.gc = GC()
    
    def active(self, value, parent):
        # Apply for memory to store the specified value and
        # return the pointer
        ptr = self.gc.allocate(heap, root, rest, value, parent)
        if ptr == -1:
            # If the application for memory fails,
            # garbage collection is automatically performed
            print("Memory full, garbage collect automatically ~ ", file=sys.stderr)
            self.gc_exec()
        else:
            return ptr
        # Try redistribution after recycling
        ptr = self.gc.allocate(heap, root, rest, value, parent)
        if ptr != -1:
            return ptr
        else:
            print("Allocate memory failed ~ ", file=sys.stderr)
            exit(1)
        

    def deactive(self, ptr):
        # Release the memory of variables
        self.gc.free(ptr)

    def gc_exec(self):
        # Marking - sweep garbage collection
        self.gc.mark()
        self.gc.sweep()
        print("GC success ~ Available memory =>", rest, file=sys.stderr)

    def get_value(self, ptr):
        # Get the value of the pointer of the object
        return get_chunk_info(ptr)["value"]

    def print_heap(self, hint):
        # Print the state of memory (heap)
        global heap, rest, rest
        print(hint)
        print("Root => ", sorted(root))
        print("Rest => ", sorted(rest, key=lambda x:x[0]))
        idx = 0
        while(idx < len(heap)):
            dic = chunk2dict(heap[idx:idx+4])
            print("Chunk Ptr " + str(idx) + "  is_mark: " + str(dic["is_mark"]) + " next: " + str(dic["next"]) + " child: " + str(dic["child"]) + " val: " + str(dic["value"]))
            idx += 4
        print("\n\n")


if __name__ == "__main__":
    manager = Manager(100)

    # Request allocation of the first memory location
    val_p1 = manager.active(1, -1)

    # Request the allocation of the second memory location
    # as the first one's child node
    val_p1 = manager.active(2, val_p1)

    # Continuously allocate 23 root memory locations
    for _ in range(23):
        manager.active(_, -1)

    # heap is full, and print
    manager.print_heap("Insert 25 val, Heap should be full now >>>")

    # Free 3rd 4rd 6th chunk and print heap
    manager.deactive(8)
    manager.deactive(12)
    manager.deactive(20)
    manager.print_heap("Free 3rd 4rd 6th chunk without gc >>>")

    # memory recycling, print the status of after recycling
    manager.gc_exec()
    manager.print_heap("GC >>>")
