# -*- coding: utf-8 -*-

import mygc1 as gc

manager = gc.Manager(100)

# Basic operations use manager to manage memory.
def add1(x):
    val1 = manager.active(x, -1)
    val2 = manager.active(1, -1)
    result = manager.active(manager.get_value(val1) + manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return  result

def sub1(x):
    val1 = manager.active(x, -1)
    val2 = manager.active(1, -1)
    result = manager.active(manager.get_value(val1) - manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return  result
    
def add(x, y):
    val1 = manager.active(x, -1)
    val2 = manager.active(y, -1)
    result = manager.active(manager.get_value(val1) + manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return  result

def sub(x, y):
    val1 = manager.active(x, -1)
    val2 = manager.active(y, -1)
    result = manager.active(manager.get_value(val1) - manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return  result

def mul(x, y):
    val1 = manager.active(x, -1)
    val2 = manager.active(y, -1)
    result = manager.active(manager.get_value(val1) * manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return  result

def exp(x, y):
    val1 = manager.active(x, -1)
    val2 = manager.active(y, -1)
    result = manager.active(manager.get_value(val1) ** manager.get_value(val2), -1)
    manager.deactive(val1)
    manager.deactive(val2)
    return  result


def iszero(x):

    if x == 0:

        return Lambda(Variable('x'), Lambda(Variable('y'), Variable('x')))

    else:

        return Lambda(Variable('x'), Lambda(Variable('y'), Variable('y')))




class ISWIM:
    pass


class Variable(ISWIM):
    def __init__(self, name):

        self.name = name

    def __str__(self):

        return self.name

    __repr__ = __str__


class Constant(ISWIM):
    def __init__(self, const):
        self.const = const


    def __str__(self):

        return str(self.const)

    __repr__ = __str__


class Lambda(ISWIM):
    def __init__(self, parameter, body):
        """

        :param parameter: a Variable
        :return:
        """
        self.parameter = parameter
        self.body = body

    def apply(self, v):

        return  replace(self.body, self.parameter, v)

    def __str__(self):

        return "(lambda (%s) (%s))" %(str(self.parameter), str(self.body))

    __repr__ = __str__



class Apply(ISWIM):
    def __init__(self, M1, M2):

        self.M1 = M1

        self.M2 = M2

    def reduce(self):

        return self.M1.apply(self.M2)

    def __str__(self):

        return "(apply (%s) (%s))" %(str(self.M1), str(self.M2))

    __repr__ = __str__
  


class PrimitiveApply(ISWIM):

    def __init__(self, name, args):

        self.name = name

        if name == "add":

            self.op = add

        elif name == "add1":

            self.op = add1

        elif name == "sub1":

            self.op = sub1


        elif name == "sub":

            self.op = sub

        elif name == "mul":

            self.op = mul


        elif name == "exp":

            self.op = exp

        else:

            print("invalid name")


        self.args = args

    def __str__(self):

        return "(%s (%s))" %(str(self.name), str(self.args))

    __repr__ = __str__


def isValue(e):

    return isinstance(e, Constant) or isinstance(e, Variable) or isinstance(e, Lambda)


def replace(M,  x, v):

    if isinstance(M, Variable):

        if M.name == x.name:

            return v

        else:
            return M


    if isinstance(M, Constant):

        return M

    if isinstance(M, Apply):

        return Apply(replace(M.M1, x, v), replace(M.M2, x, v))

    if isinstance(M, PrimitiveApply):

        newArgs = [replace(arg, x, v) for arg in M.args]

        return PrimitiveApply(M.name, newArgs)


    if isinstance(M, Lambda):

        return Lambda(M.parameter, replace(M.body, x, v))


    print("error in replace")

    return M


def interpret(e):

    if isinstance(e, Constant):

        return e

    if isinstance(e, Variable):

        return e

    if isinstance(e, Lambda ):

        return e

    if isinstance(e, Apply):

        if isValue(e.M2):

            return interpret(e.reduce())

        else:

            e.M2 = interpret(e.M2)

            return interpret(e)

    if isinstance(e, PrimitiveApply):

        for i in range(len(e.args)):

            if not isValue(e.args[i]):

                e.args[i] = interpret(e.args[i])

                return interpret(e)


        cs = [t.const for t in e.args]

        # release memory by manager
        res = e.op(*cs)
        c_res = Constant(manager.get_value(res))
        manager.deactive(res)

        return c_res


def run(e):

    print(interpret(e))


def test():

    print("run add 1 2")

    run(PrimitiveApply("add",  [Constant(1), Constant(2)]))


    print("run ((Lambda xy. (+ x y)) 10) ")
    run(Apply(Lambda(Variable("x"), Lambda(Variable("y"), PrimitiveApply("add", [Variable("x"), Variable("y")]) )  ), Constant(10)))


    print("run exercise 5.1 example")

    e1 =   Lambda (Variable('w'), PrimitiveApply('sub', [  Apply( Variable('w'),  Constant(1)), Constant(5) ]) )


    e2 = Lambda(Variable('x'),  Apply(Variable('x'), Constant(10)))


    e3 =  Lambda(Variable('y'),  Lambda(Variable('z'),  PrimitiveApply('add',  [Variable('z'),  Variable('y')]) ) )


    e4 = Apply(e2,  e3)

    run(e4)

    e5 = Apply(e1, e4)

    run(e5)



if __name__ == '__main__':

    test()

